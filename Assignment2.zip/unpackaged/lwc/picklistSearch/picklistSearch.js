import { LightningElement, track,wire,api } from 'lwc';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import TYPE_FIELD from '@salesforce/schema/Account.Type';
import getAccountDetails from '@salesforce/apex/AssignmentClass02.getAccountDetailsByType'

export default class PicklistSearch extends LightningElement {

    @track searchTermForAccount='Prospect';
    @api updatedAccountdetails;
    @track error;
    //@track searchTermForAccount;
    // @wire (getAccountDetails,{type:this.value}) accountinfo({data,error}){
    //     if(data){
    //         this.updatedAccountdetails=data;
    //     }else if(error){
    //         this.error=error;
    //     }
    // };
    @wire(getPicklistValues, { recordTypeId: '012000000000000AAA', fieldApiName: TYPE_FIELD }) propertyOrFunction;
    constructor(){
        super();
        console.log('In the comstructor');
    }
    handleAccountTypeChange(event){
        this.searchTermForAccount=event.detail.value;
        console.log('Value entered by combo box',this.value );
    }
    handleSearchAccount(){
       this.dispatchEvent(new CustomEvent('searchtermselectd',{detail:this.searchTermForAccount}));
          
    }
    get options() {

        return this.propertyOrFunction.data?this.propertyOrFunction.data.values:{};
        // return [
        //     { label: 'Prospect', value: 'Prospect' },
        //     { label: 'Customer - Direct', value: 'Customer - Direct' },
        //     { label: 'Customer - Channel', value: 'Customer - Channel' },
        //     { label: 'Channel Partner / Reseller', value: 'Channel Partner / Reseller' },
        //     { label: 'Installation Partner', value: 'Installation Partner' },
        //     { label: 'Technology Partner', value: 'Technology Partner' },
        //     { label: 'Other', value: 'Other' },
        // ];
    }
}
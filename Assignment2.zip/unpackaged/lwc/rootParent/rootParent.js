import { LightningElement,track } from 'lwc';

export default class RootParent extends LightningElement {

    @track stEvent;
    handleSearchAccountsDataEvent(event){
        console.log(event.detail);
        this.stEvent=event.detail;
    }
}
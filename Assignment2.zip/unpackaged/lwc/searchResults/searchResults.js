import { LightningElement,api, wire,track } from 'lwc';
import {registerListener, unregisterAllListeners,fireEvent} from 'c/pubsub';
import {CurrentPageReference} from 'lightning/navigation';
import getAccountDetailsByType from '@salesforce/apex/AssignmentClass02.getAccountDetailsByType';
import getAccountDetails from '@salesforce/apex/AssignmentClass02.getAccountDetails';
import { refreshApex } from '@salesforce/apex';
const DELAY = 300;
export default class SearchResults extends LightningElement {

    @api selectedItem;
    @wire (CurrentPageReference) pageRef;
    @wire (getAccountDetailsByType,{type: '$selectedItem'}) accountList;
   
    
    connectedCallback(){
        console.log('In the connected callback ldsconatiner searchResultss');
        console.log(this.pageRef);
        console.log('In the connected callback ldsconatiner---->register Listender searchResultss');
       // registerListener('pubsubeventforrefresh',this.handlepubsubEvent,this);
        registerListener('pubsubeventforrefreshforeachlist',this.handlepubsubEventRefresh,this);
    }
    disconnectedCallback(){
        unregisterAllListeners(this);
    }
    
    handlepubsubEventRefresh(data){
        console.log('pub sub event listender refresh searchResultss',data);
        refreshApex(this.accountList);
        console.log(this.accountList);
        
    }
    
}
import { LightningElement } from 'lwc';

export default class HeaderComponent extends LightningElement {}
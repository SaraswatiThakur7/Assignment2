import { LightningElement, api ,wire} from 'lwc';
import {fireEvent} from 'c/pubsub';
import {CurrentPageReference} from 'lightning/navigation';

export default class CardComponent extends LightningElement {

    @api account;
    @wire (CurrentPageReference) pageRef;
    handleDisplayAccount(){
        console.log('pubsub event got fired');
        console.log(this.pageRef);
        console.log(this.account.Id);//this.account
        fireEvent(this.pageRef,'pubsubevent',this.account.Id);
    }
}
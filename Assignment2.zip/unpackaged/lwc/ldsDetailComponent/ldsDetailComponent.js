import { LightningElement, wire,track,api } from 'lwc';
import {registerListener, unregisterAllListeners,fireEvent} from 'c/pubsub';
import {CurrentPageReference} from 'lightning/navigation';
import {ShowToastEvent} from 'lightning/platformShowToastEvent'
import { refreshApex } from '@salesforce/apex';
import { getRecord } from 'lightning/uiRecordApi';
import { updateRecord } from 'lightning/uiRecordApi';
import getAccountDetails from '@salesforce/apex/AssignmentClass02.getAccountDetails';
import NAME_FIELD from '@salesforce/schema/Account.Name';
import OWNER_NAME_FIELD from '@salesforce/schema/Account.Owner.Name';
import PHONE_FIELD from '@salesforce/schema/Account.Phone';
import INDUSTRY_FIELD from '@salesforce/schema/Account.Industry';
import WEBSITE from '@salesforce/schema/Account.Website';
import TYPE from '@salesforce/schema/Account.Type';
import Id_FEILD from '@salesforce/schema/Account.Id';
const DELAY = 300;
export default class LdsDetailComponent extends LightningElement {

    @wire (CurrentPageReference) pageRef;
    @track selectedAccountId;
    @track viewMode='Edit';
    
    fields=[NAME_FIELD, PHONE_FIELD, INDUSTRY_FIELD,WEBSITE,TYPE    ];
    //@wire(getRecord, { recordId: this.selectedAccountId, fields: [NAME_FIELD,OWNER_NAME_FIELD,PHONE_FIELD,INDUSTRY_FIELD] }) account;
    @track selectedAccount;
    @track updatedAccount;
    @track open=false;

    constructor(){
        super();
    }
    connectedCallback(){
        console.log('In the connected callback ldsconatiner');
        console.log(this.pageRef);
        console.log('In the connected callback ldsconatiner---->register Listender');
        registerListener('pubsubevent',this.handlepubsubEvent,this);
        registerListener('pubsubeventforrefresh',this.handlepubsubEventRefresh,this);
        
    }
    renderedCallback(){
        
    }
    handlepubsubEventRefresh(data){
        console.log('pub sub event listender refresh',data);
        window.clearTimeout(this.delayTimeout);
        
        this.delayTimeout = setTimeout(() => {
            getAccountDetails({recordId : data})
        .then((data)=>{
            console.log('Real account data');
            console.log(data);
            this.selectedAccount=data;
        })
        .catch((error)=>{console.log(error)});
        }, DELAY);
        console.log(data);
        
    }
    handlepubsubEvent(data){
        console.log('pub sub event listender');
        console.log(data);
        this.selectedAccountId=data;
        let resultedAccount=getAccountDetails({recordId : this.selectedAccountId})
        .then((data)=>{
            console.log('Real account data');
            console.log(data);
            this.selectedAccount=data;
        })
        .catch((error)=>{console.log(error)});
    }
    disconnectedCallback(){
        unregisterAllListeners(this);
    }
    handleSubmit(event){
        event.preventDefault();       // stop the form from submitting
        const fields = event.detail.fields;
        this.template.querySelector('lightning-record-form').submit(fields);
        this.open = false;
        
        
        
        
       
     }
   
     handleSuccess(){
        const evt = new ShowToastEvent({
            title: "Success!",
            message: "The record has been successfully saved.",
            variant: "success",
        });
        this.dispatchEvent(evt);
        this.viewMode='View';
        fireEvent(this.pageRef,'pubsubeventforrefresh',this.selectedAccountId);
        fireEvent(this.pageRef,'pubsubeventforrefreshforeachlist',this.selectedAccountId);
        console.log('fired Event ');
        
     }
     handleAccoundDetailsChange(event){

        this.updatedAccount=this.selectedAccount[0];
        console.log(this.updatedAccount);

        console.log("In HandleClick");
        const recId = this.selectedAccountId;
        console.log("Selected Account Id:::", recId);
        this.open = true;
     }
     closeModal() {
        console.log("In closeModal");
        this.open = false;
    }
    
}